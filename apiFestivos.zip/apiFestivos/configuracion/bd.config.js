module.exports = {
    SERVIDOR: '0.0.0.0',
    PUERTO: '27017',
    BASEDATOS: 'festivos',
    USUARIO: '',
    CLAVE: ''
}